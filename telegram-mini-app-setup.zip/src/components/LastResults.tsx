import { Trophy } from 'lucide-react';
import { useAppStore } from '../store';

export function LastResults() {
  const { lastResults } = useAppStore();

  if (!lastResults) return null;

  return (
    <div className="rounded-2xl bg-gradient-to-br from-amber-50 to-yellow-50 p-4 border border-amber-200">
      <div className="flex items-center gap-3 mb-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500 text-white">
          <Trophy className="h-5 w-5" />
        </div>
        <h3 className="font-bold text-amber-800">Последние итоги</h3>
      </div>
      <div className="whitespace-pre-line text-sm text-amber-700">
        {lastResults.text}
      </div>
    </div>
  );
}
