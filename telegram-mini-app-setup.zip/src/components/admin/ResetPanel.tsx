import { useState } from 'react';
import { RotateCcw, AlertTriangle, Trash2 } from 'lucide-react';
import { useAppStore } from '../../store';

export function ResetPanel() {
  const { resetContest, users, setAdminView } = useAppStore();
  const [confirmed, setConfirmed] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const handleReset = () => {
    if (inputValue !== 'СБРОСИТЬ') return;
    
    resetContest();
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('warning');
    setConfirmed(true);
    
    setTimeout(() => {
      setAdminView('main');
    }, 2000);
  };

  if (confirmed) {
    return (
      <div className="rounded-2xl bg-green-50 p-6 text-center border border-green-200">
        <div className="flex h-16 w-16 mx-auto items-center justify-center rounded-full bg-green-500 text-white mb-4">
          <Trash2 className="h-8 w-8" />
        </div>
        <h3 className="text-xl font-bold text-green-800 mb-2">Конкурс сброшен!</h3>
        <p className="text-green-600">Все данные участников удалены</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-red-50 p-5 border border-red-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-500 text-white">
            <AlertTriangle className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-red-800">⚠️ Сброс конкурса</h2>
            <p className="text-sm text-red-600">Это действие необратимо!</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl bg-white p-4 border border-red-200">
            <p className="text-red-700 font-medium mb-2">
              Будут удалены:
            </p>
            <ul className="text-sm text-red-600 space-y-1">
              <li>• Все участники конкурса ({users.length} чел.)</li>
              <li>• Все реферальные ссылки</li>
              <li>• Все баллы</li>
            </ul>
          </div>

          <div className="rounded-xl bg-amber-50 p-4 border border-amber-200">
            <p className="text-amber-700 text-sm">
              💡 <strong>База постоянных пользователей</strong> (для рассылок) <strong>НЕ будет</strong> удалена
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-red-700 mb-2">
              Введите "СБРОСИТЬ" для подтверждения
            </label>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="СБРОСИТЬ"
              className="w-full rounded-xl border border-red-300 p-4 text-center text-lg font-bold text-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>

          <button
            onClick={handleReset}
            disabled={inputValue !== 'СБРОСИТЬ'}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 py-4 text-white font-semibold shadow-lg shadow-red-200 transition-all hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed active:scale-98"
          >
            <RotateCcw className="h-5 w-5" />
            Сбросить конкурс
          </button>
        </div>
      </div>
    </div>
  );
}
