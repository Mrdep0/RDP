import { useState } from 'react';
import { Trophy, Loader2, Sparkles } from 'lucide-react';
import { useAppStore } from '../../store';
import type { User } from '../../types';

export function WinnersPanel() {
  const { users, drawWinners, saveResults } = useAppStore();
  const [count, setCount] = useState('3');
  const [drawing, setDrawing] = useState(false);
  const [winners, setWinners] = useState<User[]>([]);

  const validParticipants = users.filter(u => u.is_validated && u.score > 0);

  const handleDraw = async () => {
    const num = parseInt(count);
    if (isNaN(num) || num < 1) return;

    setDrawing(true);
    
    // Animation delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const result = drawWinners(num);
    setWinners(result);
    
    if (result.length > 0) {
      const resultText = result
        .map((w, i) => `${i + 1}. ${w.full_name} (${w.username || 'без username'}) — Баллов: ${w.score}`)
        .join('\n');
      saveResults(resultText);
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
    }
    
    setDrawing(false);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white">
            <Trophy className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">🏆 Розыгрыш итогов</h2>
            <p className="text-sm text-gray-500">
              Участников с баллами: {validParticipants.length}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Количество победителей
            </label>
            <input
              type="number"
              min="1"
              max={validParticipants.length || 1}
              value={count}
              onChange={(e) => setCount(e.target.value)}
              className="w-full rounded-xl border border-gray-200 p-4 text-gray-800 text-center text-2xl font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
            />
          </div>

          <div className="rounded-xl bg-amber-50 p-4 border border-amber-200">
            <p className="text-sm text-amber-700">
              💡 Победители выбираются случайно с учётом количества баллов. 
              Чем больше баллов — тем выше шанс победить!
            </p>
          </div>

          <button
            onClick={handleDraw}
            disabled={drawing || validParticipants.length === 0}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 py-4 text-white font-semibold shadow-lg shadow-amber-200 transition-all hover:shadow-xl disabled:opacity-50 active:scale-98"
          >
            {drawing ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Определяем победителей...
              </>
            ) : (
              <>
                <Sparkles className="h-5 w-5" />
                Провести розыгрыш
              </>
            )}
          </button>
        </div>
      </div>

      {winners.length > 0 && (
        <div className="rounded-2xl bg-gradient-to-br from-amber-50 to-yellow-50 p-5 border border-amber-200">
          <h3 className="text-lg font-bold text-amber-800 mb-4 flex items-center gap-2">
            🎉 Победители!
          </h3>
          <div className="space-y-3">
            {winners.map((winner, index) => (
              <div 
                key={winner.user_id}
                className="flex items-center gap-3 rounded-xl bg-white p-3 shadow-sm border border-amber-200"
              >
                <div className={`flex h-10 w-10 items-center justify-center rounded-full font-bold text-white ${
                  index === 0 ? 'bg-amber-500' : 
                  index === 1 ? 'bg-gray-400' : 
                  index === 2 ? 'bg-amber-700' : 'bg-gray-500'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-800">{winner.full_name}</p>
                  <p className="text-sm text-gray-500">{winner.username || 'без username'}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-amber-600">{winner.score}</p>
                  <p className="text-xs text-gray-500">баллов</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {validParticipants.length === 0 && (
        <div className="rounded-xl bg-red-50 p-4 text-center border border-red-200">
          <p className="text-red-600">Нет участников с баллами для розыгрыша</p>
        </div>
      )}
    </div>
  );
}
