import { 
  Megaphone, Trophy, Users, Download, Settings, RotateCcw, 
  ArrowLeft 
} from 'lucide-react';
import { useAppStore } from '../../store';
import { BroadcastPanel } from './BroadcastPanel';
import { WinnersPanel } from './WinnersPanel';
import { UsersPanel } from './UsersPanel';
import { ExportPanel } from './ExportPanel';
import { SettingsPanel } from './SettingsPanel';
import { ResetPanel } from './ResetPanel';

export function AdminPanel() {
  const { adminView, setAdminView, setView } = useAppStore();

  const menuItems = [
    { id: 'broadcast', icon: Megaphone, label: '📢 Рассылка', color: 'from-blue-500 to-blue-600' },
    { id: 'winners', icon: Trophy, label: '🏆 Итоги', color: 'from-amber-500 to-orange-500' },
    { id: 'users', icon: Users, label: '📁 База юзеров', color: 'from-green-500 to-emerald-600' },
    { id: 'export', icon: Download, label: '📊 Экспорт участников', color: 'from-purple-500 to-violet-600' },
    { id: 'settings', icon: Settings, label: '⚙️ Настройки', color: 'from-gray-500 to-gray-600' },
    { id: 'reset', icon: RotateCcw, label: '⚠️ Сброс конкурса', color: 'from-red-500 to-rose-600' },
  ] as const;

  if (adminView !== 'main') {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setAdminView('main')}
          className="flex items-center gap-2 text-indigo-600 font-medium"
        >
          <ArrowLeft className="h-5 w-5" />
          Назад в меню
        </button>

        {adminView === 'broadcast' && <BroadcastPanel />}
        {adminView === 'winners' && <WinnersPanel />}
        {adminView === 'users' && <UsersPanel />}
        {adminView === 'export' && <ExportPanel />}
        {adminView === 'settings' && <SettingsPanel />}
        {adminView === 'reset' && <ResetPanel />}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 p-5 text-white shadow-xl">
        <h2 className="text-xl font-bold mb-1">🛠 Админ-панель</h2>
        <p className="text-white/70 text-sm">Управление розыгрышем</p>
      </div>

      <div className="grid gap-3">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setAdminView(item.id)}
              className={`flex items-center gap-4 rounded-2xl bg-gradient-to-r ${item.color} p-4 text-white shadow-lg transition-all hover:shadow-xl active:scale-98`}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
                <Icon className="h-6 w-6" />
              </div>
              <span className="text-lg font-semibold">{item.label}</span>
            </button>
          );
        })}
      </div>

      <button
        onClick={() => setView('main')}
        className="w-full rounded-xl bg-gray-100 py-3 text-gray-700 font-medium transition-all hover:bg-gray-200 active:scale-98"
      >
        ⬅️ Выйти из админки
      </button>
    </div>
  );
}
