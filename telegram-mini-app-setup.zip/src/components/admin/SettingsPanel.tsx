import { useState } from 'react';
import { Settings, Save, CheckCircle } from 'lucide-react';
import { useAppStore } from '../../store';

export function SettingsPanel() {
  const { settings, updateHowto } = useAppStore();
  const [text, setText] = useState(settings.howto);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    updateHowto(text);
    setSaved(true);
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gray-500 text-white">
            <Settings className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">⚙️ Настройки</h2>
            <p className="text-sm text-gray-500">Редактирование текстов</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Текст "Как это работает?"
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full rounded-xl border border-gray-200 p-4 text-gray-800 resize-none focus:outline-none focus:ring-2 focus:ring-gray-500 focus:border-transparent"
              rows={10}
            />
            <p className="mt-1 text-xs text-gray-500">
              Поддерживается HTML: &lt;b&gt;жирный&lt;/b&gt;
            </p>
          </div>

          <button
            onClick={handleSave}
            className={`flex w-full items-center justify-center gap-2 rounded-xl py-4 font-semibold transition-all ${
              saved 
                ? 'bg-green-500 text-white' 
                : 'bg-gradient-to-r from-gray-600 to-gray-700 text-white shadow-lg shadow-gray-200 hover:shadow-xl'
            }`}
          >
            {saved ? (
              <>
                <CheckCircle className="h-5 w-5" />
                Сохранено!
              </>
            ) : (
              <>
                <Save className="h-5 w-5" />
                Сохранить изменения
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
