import { useState } from 'react';
import { Download, Copy, CheckCircle, Trophy } from 'lucide-react';
import { useAppStore } from '../../store';

export function ExportPanel() {
  const { users } = useAppStore();
  const [copied, setCopied] = useState(false);

  const validParticipants = users.filter(u => u.is_validated);
  const sortedParticipants = [...validParticipants].sort((a, b) => b.score - a.score);

  const handleExport = async () => {
    const data = `УЧАСТНИКИ КОНКУРСА: ${validParticipants.length}\n${'='.repeat(40)}\n` +
      sortedParticipants.map(u => 
        `ID: ${u.user_id} | Тег: ${u.username || 'Нет'} | Имя: ${u.full_name} | БАЛЛЫ: ${u.score}`
      ).join('\n');
    
    try {
      await navigator.clipboard.writeText(data);
      setCopied(true);
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback - download as file
      const blob = new Blob([data], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'contest_participants.txt';
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500 text-white">
            <Download className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">📊 Экспорт участников</h2>
            <p className="text-sm text-gray-500">Участников: {validParticipants.length}</p>
          </div>
        </div>

        <button
          onClick={handleExport}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-4 font-semibold transition-all ${
            copied 
              ? 'bg-green-500 text-white shadow-lg shadow-green-200' 
              : 'bg-gradient-to-r from-purple-500 to-violet-600 text-white shadow-lg shadow-purple-200 hover:shadow-xl'
          }`}
        >
          {copied ? (
            <>
              <CheckCircle className="h-5 w-5" />
              Скопировано в буфер!
            </>
          ) : (
            <>
              <Copy className="h-5 w-5" />
              Экспортировать данные
            </>
          )}
        </button>
      </div>

      {/* Leaderboard */}
      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Trophy className="h-5 w-5 text-amber-500" />
          Топ участников
        </h3>

        <div className="space-y-2 max-h-80 overflow-y-auto">
          {sortedParticipants.slice(0, 20).map((user, index) => (
            <div 
              key={user.user_id}
              className={`flex items-center gap-3 rounded-xl p-3 ${
                index < 3 
                  ? 'bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200' 
                  : 'bg-gray-50 border border-gray-100'
              }`}
            >
              <div className={`flex h-8 w-8 items-center justify-center rounded-full font-bold text-sm ${
                index === 0 ? 'bg-amber-500 text-white' : 
                index === 1 ? 'bg-gray-400 text-white' : 
                index === 2 ? 'bg-amber-700 text-white' : 
                'bg-gray-200 text-gray-600'
              }`}>
                {index + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-800 truncate">{user.full_name}</p>
                <p className="text-xs text-gray-500 truncate">{user.username || 'без username'}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-amber-600">{user.score}</p>
                <p className="text-xs text-gray-500">баллов</p>
              </div>
            </div>
          ))}

          {sortedParticipants.length === 0 && (
            <div className="rounded-xl bg-gray-50 p-4 text-center">
              <p className="text-gray-500">Нет подтверждённых участников</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
