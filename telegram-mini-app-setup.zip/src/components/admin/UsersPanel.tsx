import { useState } from 'react';
import { Users, Search, Copy, CheckCircle } from 'lucide-react';
import { useAppStore } from '../../store';

export function UsersPanel() {
  const { permanentUsers } = useAppStore();
  const [search, setSearch] = useState('');
  const [copied, setCopied] = useState(false);

  const filteredUsers = permanentUsers.filter(user => 
    user.full_name.toLowerCase().includes(search.toLowerCase()) ||
    user.username.toLowerCase().includes(search.toLowerCase()) ||
    user.user_id.toString().includes(search)
  );

  const handleExport = async () => {
    const data = `ВСЕГО ПОЛЬЗОВАТЕЛЕЙ В БАЗЕ: ${permanentUsers.length}\n${'='.repeat(40)}\n` +
      permanentUsers.map(u => `ID: ${u.user_id} | Тег: ${u.username || 'Нет'} | Имя: ${u.full_name}`).join('\n');
    
    try {
      await navigator.clipboard.writeText(data);
      setCopied(true);
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const blob = new Blob([data], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'users_base.txt';
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500 text-white">
            <Users className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">📁 База юзеров</h2>
            <p className="text-sm text-gray-500">Всего: {permanentUsers.length}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Поиск по имени, тегу или ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-gray-200 py-3 pl-12 pr-4 text-gray-800 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          <button
            onClick={handleExport}
            className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium transition-all ${
              copied 
                ? 'bg-green-500 text-white' 
                : 'bg-green-100 text-green-700 hover:bg-green-200'
            }`}
          >
            {copied ? (
              <>
                <CheckCircle className="h-5 w-5" />
                Скопировано!
              </>
            ) : (
              <>
                <Copy className="h-5 w-5" />
                Экспортировать всё
              </>
            )}
          </button>
        </div>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {filteredUsers.map((user) => (
          <div 
            key={user.user_id}
            className="rounded-xl bg-white p-3 shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-800">{user.full_name}</p>
                <p className="text-sm text-gray-500">
                  {user.username || 'Нет тега'} • ID: {user.user_id}
                </p>
              </div>
              {user.join_date && (
                <span className="text-xs text-gray-400">{user.join_date}</span>
              )}
            </div>
          </div>
        ))}

        {filteredUsers.length === 0 && (
          <div className="rounded-xl bg-gray-50 p-4 text-center">
            <p className="text-gray-500">Пользователи не найдены</p>
          </div>
        )}
      </div>
    </div>
  );
}
