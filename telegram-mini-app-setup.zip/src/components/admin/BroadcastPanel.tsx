import { useState } from 'react';
import { Send, Loader2, CheckCircle, Image } from 'lucide-react';
import { useAppStore } from '../../store';

export function BroadcastPanel() {
  const { permanentUsers } = useAppStore();
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [result, setResult] = useState<{ sent: number; total: number } | null>(null);

  const handleSend = async () => {
    if (!message.trim()) return;

    setSending(true);
    
    // Simulate sending (in real app, this calls your backend)
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const sentCount = Math.floor(permanentUsers.length * 0.95); // Simulate 95% delivery
    
    setSending(false);
    setSent(true);
    setResult({ sent: sentCount, total: permanentUsers.length });
    
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
    
    setTimeout(() => {
      setSent(false);
      setMessage('');
      setResult(null);
    }, 3000);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500 text-white">
            <Send className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">📢 Рассылка</h2>
            <p className="text-sm text-gray-500">Получателей: {permanentUsers.length}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Текст сообщения
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Введите текст рассылки..."
              className="w-full rounded-xl border border-gray-200 p-4 text-gray-800 resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              rows={6}
            />
            <p className="mt-1 text-xs text-gray-500">
              Поддерживается HTML-форматирование: &lt;b&gt;жирный&lt;/b&gt;
            </p>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-200">
            <Image className="h-5 w-5 text-gray-400" />
            <span className="text-sm text-gray-500">
              Загрузка изображений доступна через бота
            </span>
          </div>

          {result && (
            <div className="rounded-xl bg-green-50 p-4 border border-green-200">
              <div className="flex items-center gap-2 text-green-700">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">
                  Доставлено: {result.sent} из {result.total}
                </span>
              </div>
            </div>
          )}

          <button
            onClick={handleSend}
            disabled={sending || !message.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 py-4 text-white font-semibold shadow-lg shadow-blue-200 transition-all hover:shadow-xl disabled:opacity-50 active:scale-98"
          >
            {sending ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Отправка...
              </>
            ) : sent ? (
              <>
                <CheckCircle className="h-5 w-5" />
                Отправлено!
              </>
            ) : (
              <>
                <Send className="h-5 w-5" />
                Отправить всем
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
