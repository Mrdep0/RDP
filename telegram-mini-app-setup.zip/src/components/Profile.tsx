import { useState } from 'react';
import { User, Copy, Share2, Star, CheckCircle, Users } from 'lucide-react';
import { useAppStore } from '../store';

export function Profile() {
  const { currentUser, getRefLink, users } = useAppStore();
  const [copied, setCopied] = useState(false);

  if (!currentUser) return null;

  const refLink = getRefLink(currentUser.user_id);
  const invitedCount = users.filter(u => u.referrer_id === currentUser.user_id && u.is_validated).length;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(refLink);
      setCopied(true);
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = refLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = () => {
    const text = `🎁 Участвуй в розыгрыше!\n${refLink}`;
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(text)}`;
    
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.openTelegramLink(shareUrl);
    } else {
      window.open(shareUrl, '_blank');
    }
  };

  return (
    <div className="space-y-4">
      {/* Profile Card */}
      <div className="rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 p-5 text-white shadow-xl">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm">
            <User className="h-8 w-8" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold">{currentUser.full_name}</h2>
            <p className="text-white/70">{currentUser.username || 'Нет username'}</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 p-4 border border-amber-200">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white">
              <Star className="h-6 w-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-700">{currentUser.score}</p>
              <p className="text-sm text-amber-600">Баллов</p>
            </div>
          </div>
        </div>
        
        <div className="rounded-2xl bg-gradient-to-br from-blue-50 to-cyan-50 p-4 border border-blue-200">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500 text-white">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-700">{invitedCount}</p>
              <p className="text-sm text-blue-600">Друзей</p>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Link */}
      <div className="rounded-2xl bg-white p-4 shadow-lg border border-gray-100">
        <h3 className="mb-3 font-semibold text-gray-800 flex items-center gap-2">
          🔗 Твоя реферальная ссылка
        </h3>
        
        <div className="mb-4 rounded-xl bg-gray-50 p-3 border border-gray-200">
          <p className="break-all text-sm text-gray-600 font-mono">{refLink}</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleCopy}
            className={`flex items-center justify-center gap-2 rounded-xl py-3 font-medium transition-all ${
              copied
                ? 'bg-green-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 active:scale-98'
            }`}
          >
            {copied ? (
              <>
                <CheckCircle className="h-5 w-5" />
                Скопировано!
              </>
            ) : (
              <>
                <Copy className="h-5 w-5" />
                Копировать
              </>
            )}
          </button>
          
          <button
            onClick={handleShare}
            className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 py-3 text-white font-medium shadow-lg shadow-indigo-200 transition-all hover:shadow-xl active:scale-98"
          >
            <Share2 className="h-5 w-5" />
            Поделиться
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="rounded-xl bg-blue-50 p-4 border border-blue-200">
        <p className="text-sm text-blue-700">
          💡 <strong>Подсказка:</strong> Пригласите друга и получите +1 балл, когда он подпишется на канал. Чем больше баллов — тем выше шанс победить!
        </p>
      </div>
    </div>
  );
}
