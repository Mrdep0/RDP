import { Gift, Sparkles, Users, Trophy } from 'lucide-react';

interface WelcomeScreenProps {
  onStart: () => void;
}

export function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-600 via-purple-600 to-pink-500 flex flex-col items-center justify-center p-6 text-white">
      <div className="text-center space-y-8 max-w-sm">
        {/* Logo */}
        <div className="relative">
          <div className="w-24 h-24 mx-auto bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center animate-pulse">
            <Gift className="w-12 h-12" />
          </div>
          <Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-yellow-300 animate-bounce" />
        </div>

        {/* Title */}
        <div>
          <h1 className="text-4xl font-bold mb-2">🎁 Розыгрыш</h1>
          <p className="text-white/80 text-lg">Участвуй и побеждай!</p>
        </div>

        {/* Features */}
        <div className="space-y-4">
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-2xl p-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div className="text-left">
              <p className="font-semibold">Приглашай друзей</p>
              <p className="text-sm text-white/70">Получай баллы за каждого</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-2xl p-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
              <Trophy className="w-6 h-6" />
            </div>
            <div className="text-left">
              <p className="font-semibold">Выигрывай призы</p>
              <p className="text-sm text-white/70">Больше баллов — выше шанс</p>
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={onStart}
          className="w-full bg-white text-indigo-600 font-bold py-4 px-8 rounded-2xl shadow-lg shadow-black/20 transition-all hover:shadow-xl active:scale-98"
        >
          Начать участие
        </button>
      </div>
    </div>
  );
}
