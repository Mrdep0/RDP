import { Gift, Shield } from 'lucide-react';
import { useAppStore } from '../store';

export function Header() {
  const { isAdmin, view, setView } = useAppStore();

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
      <div className="px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
              <Gift className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold">🎁 Розыгрыш</h1>
              <p className="text-xs text-white/70">Участвуй и побеждай!</p>
            </div>
          </div>
          
          {isAdmin && (
            <button
              onClick={() => setView(view === 'admin' ? 'main' : 'admin')}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-all ${
                view === 'admin' 
                  ? 'bg-white text-indigo-600' 
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Shield className="h-4 w-4" />
              {view === 'admin' ? 'Выйти' : 'Админ'}
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
