import { HelpCircle, ArrowLeft } from 'lucide-react';
import { useAppStore } from '../store';

export function HowItWorks() {
  const { settings, setView } = useAppStore();

  // Parse simple HTML-like formatting
  const formatText = (text: string) => {
    return text
      .replace(/<b>/g, '<strong>')
      .replace(/<\/b>/g, '</strong>');
  };

  return (
    <div className="space-y-4">
      <button
        onClick={() => setView('main')}
        className="flex items-center gap-2 text-indigo-600 font-medium"
      >
        <ArrowLeft className="h-5 w-5" />
        Назад
      </button>

      <div className="rounded-2xl bg-white p-5 shadow-lg border border-gray-100">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-500 text-white">
            <HelpCircle className="h-6 w-6" />
          </div>
          <h2 className="text-xl font-bold text-gray-800">Как это работает?</h2>
        </div>
        
        <div 
          className="prose prose-sm text-gray-700 whitespace-pre-line"
          dangerouslySetInnerHTML={{ __html: formatText(settings.howto) }}
        />
      </div>
    </div>
  );
}
