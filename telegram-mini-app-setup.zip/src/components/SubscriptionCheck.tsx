import { useState } from 'react';
import { CheckCircle, ExternalLink, Loader2 } from 'lucide-react';
import { useAppStore, CHANNEL_ID } from '../store';

export function SubscriptionCheck() {
  const { currentUser, setIsSubscribed, validateSubscription } = useAppStore();
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState('');

  const handleOpenChannel = () => {
    const channelUrl = `https://t.me/${CHANNEL_ID.replace('@', '')}`;
    
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.openTelegramLink(channelUrl);
    } else {
      window.open(channelUrl, '_blank');
    }
  };

  const handleCheckSubscription = async () => {
    setChecking(true);
    setError('');
    
    // Simulate API check (in real app, this would call your backend)
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // For demo, we'll simulate successful subscription
    // In production, this should verify via Telegram Bot API
    const isSubbed = true; // This would come from your backend
    
    setIsSubscribed(isSubbed);
    
    if (isSubbed && currentUser) {
      const validated = validateSubscription(currentUser.user_id);
      if (validated) {
        window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
      }
    } else {
      setError('Вы ещё не подписаны на канал!');
      window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('error');
    }
    
    setChecking(false);
  };

  if (currentUser?.is_validated) {
    return (
      <div className="rounded-2xl bg-gradient-to-br from-green-50 to-emerald-50 p-4 border border-green-200">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-500 text-white">
            <CheckCircle className="h-6 w-6" />
          </div>
          <div>
            <p className="font-semibold text-green-800">Подписка подтверждена!</p>
            <p className="text-sm text-green-600">Вы участвуете в розыгрыше</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 p-4 border border-amber-200">
        <p className="mb-3 text-amber-800">
          👋 Чтобы участвовать в розыгрыше, подпишитесь на канал:
        </p>
        <button
          onClick={handleOpenChannel}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 py-3 text-white font-medium shadow-lg shadow-blue-200 transition-all hover:shadow-xl active:scale-98"
        >
          <ExternalLink className="h-5 w-5" />
          Открыть {CHANNEL_ID}
        </button>
      </div>

      <button
        onClick={handleCheckSubscription}
        disabled={checking}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 py-4 text-white font-semibold shadow-lg shadow-indigo-200 transition-all hover:shadow-xl disabled:opacity-70 active:scale-98"
      >
        {checking ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            Проверяем...
          </>
        ) : (
          <>
            <CheckCircle className="h-5 w-5" />
            Проверить подписку
          </>
        )}
      </button>

      {error && (
        <div className="rounded-xl bg-red-50 p-3 text-center text-red-600 border border-red-200">
          {error}
        </div>
      )}
    </div>
  );
}
